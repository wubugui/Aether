# Round 38 look-dev scenes, built and rendered on the LAN Blender Hub (never locally).
# Proper Blender workflow instead of hand-stacked boxes:
#   terrain  : procedural height field (mathutils.noise ridged/fractal) on a dense grid,
#              Decimate(COLLAPSE) modifier -> irregular low-poly facets, flat shading,
#              per-face colour attribute from height/slope/regional noise (sand, grass, rock, snow, shallows)
#   plants   : Geometry Nodes (Distribute Points on Faces by 'tree_density' attribute ->
#              Instance on Points from a tree collection, random rotation/scale)
#   clouds   : metaball-like sphere clusters -> Remesh(VOXEL) -> Decimate(COLLAPSE) faceted puffs
#   water    : blended Principled water over the coloured sea floor (shallows read through)
#   air      : world gradient sky + sun glow, world Volume Scatter for aerial perspective
#   render   : EEVEE (ray tracing on), Standard view transform
# Args after '--': preset names (default: all). Outputs to HUB_OUTPUT_DIR: <ref>.png, <ref>.blend, report.json
import bpy, bmesh, math, os, sys, json, random, traceback
from mathutils import Vector, noise, Matrix

OUT = os.environ.get('HUB_OUTPUT_DIR', os.path.abspath('output'))
os.makedirs(OUT, exist_ok=True)
HERE = os.path.dirname(os.path.abspath(__file__))

def sstep(a, b, x):
    t = max(0.0, min(1.0, (x - a) / (b - a)))
    return t * t * (3 - 2 * t)

def gauss(x, y, cx, cy, r):
    return math.exp(-((x - cx) ** 2 + (y - cy) ** 2) / (r * r))

def fbm(x, y, s, o=5, seed=0.0):
    return noise.fractal(Vector((x * s + seed, y * s - seed, seed * 0.37)), 0.8, 2.0, o, noise_basis='PERLIN_NEW')

def ridged(x, y, s, o=6, seed=0.0):
    return noise.ridged_multi_fractal(Vector((x * s + seed, y * s + seed * 1.7, 0.5)), 0.9, 2.1, o, 1.0, 2.0, noise_basis='PERLIN_NEW')

def srgb2lin(c):
    return tuple(((v / 12.92) if v <= 0.04045 else ((v + 0.055) / 1.055) ** 2.4) for v in c)

def mix(a, b, t):
    return tuple(a[i] + (b[i] - a[i]) * t for i in range(3))

# ------------------------------------------------------------------ presets
PRESETS = {
    '1343': dict(
        cam=((0, -2600, 330), (150, 700, 40), 50), size=4200, seg=260, decimate=0.28,
        sun=dict(elev=52, az=120, color=(1.0, 0.97, 0.9), strength=3.6),
        sky=dict(zenith=(0.33, 0.56, 0.86), horizon=(0.80, 0.89, 0.96), glow=(0.25, 0.22, 0.15)),
        haze=0.00009, haze_color=(0.72, 0.82, 0.95), snow=430, water=dict(color=(0.06, 0.27, 0.52), alpha=0.72, rough=0.12),
        palette='temperate', trees=0.00022, clouds=9, ship=dict(dist=95, right=-8, up=-6, yaw=35), terrain='plains'),
    '1128': dict(
        cam=((0, -1700, 16), (0, 900, 170), 58), size=3600, seg=260, decimate=0.3,
        sun=dict(elev=40, az=70, color=(1.0, 0.98, 0.94), strength=3.4),
        sky=dict(zenith=(0.45, 0.64, 0.90), horizon=(0.86, 0.91, 0.97), glow=(0.2, 0.18, 0.12)),
        haze=0.00007, haze_color=(0.80, 0.87, 0.96), snow=260, water=dict(color=(0.38, 0.55, 0.72), alpha=0.9, rough=0.015),
        palette='alpine', trees=0.00035, clouds=7, ship=dict(dist=150, right=10, up=18, yaw=90), terrain='lake'),
    '1218': dict(
        cam=((0, -2500, 720), (0, 900, 0), 60), size=4200, seg=260, decimate=0.28,
        sun=dict(elev=60, az=210, color=(1.0, 0.98, 0.92), strength=3.8),
        sky=dict(zenith=(0.18, 0.46, 0.92), horizon=(0.72, 0.87, 0.99), glow=(0.2, 0.18, 0.12)),
        haze=0.00006, haze_color=(0.72, 0.84, 0.98), snow=520, water=dict(color=(0.03, 0.30, 0.62), alpha=0.68, rough=0.1),
        palette='bright', trees=0.00045, clouds=8, ship=dict(dist=110, right=-26, up=16, yaw=20), terrain='archipelago'),
    '1220': dict(
        cam=((200, -2200, 420), (-150, 1500, 110), 55), size=4200, seg=260, decimate=0.28,
        sun=dict(elev=2.5, az=100, color=(1.0, 0.55, 0.28), strength=4.0),
        sky=dict(zenith=(0.22, 0.24, 0.48), horizon=(1.0, 0.52, 0.28), glow=(1.6, 0.7, 0.2)),
        haze=0.00012, haze_color=(0.95, 0.55, 0.4), snow=520, water=dict(color=(0.10, 0.12, 0.28), alpha=0.8, rough=0.06),
        palette='sunset', trees=0.00025, clouds=10, ship=dict(dist=70, right=-22, up=10, yaw=10), terrain='bay'),
}

PALETTES = {
    'temperate': dict(sand=(0.84, 0.78, 0.62), grass=(0.47, 0.64, 0.27), grass2=(0.62, 0.72, 0.33), forest=(0.30, 0.47, 0.22),
                      rock=(0.52, 0.53, 0.55), rock2=(0.40, 0.42, 0.45), snow=(0.95, 0.97, 1.0), shallow=(0.35, 0.72, 0.74), deep=(0.05, 0.25, 0.50)),
    'alpine': dict(sand=(0.70, 0.68, 0.62), grass=(0.42, 0.56, 0.30), grass2=(0.55, 0.62, 0.36), forest=(0.22, 0.36, 0.22),
                   rock=(0.50, 0.52, 0.56), rock2=(0.36, 0.38, 0.42), snow=(0.96, 0.97, 1.0), shallow=(0.52, 0.66, 0.70), deep=(0.26, 0.40, 0.55)),
    'bright': dict(sand=(0.93, 0.87, 0.66), grass=(0.36, 0.68, 0.24), grass2=(0.55, 0.80, 0.30), forest=(0.16, 0.45, 0.18),
                   rock=(0.56, 0.55, 0.52), rock2=(0.44, 0.44, 0.42), snow=(0.96, 0.97, 1.0), shallow=(0.25, 0.82, 0.80), deep=(0.02, 0.28, 0.62)),
    'sunset': dict(sand=(0.80, 0.62, 0.45), grass=(0.42, 0.45, 0.25), grass2=(0.55, 0.50, 0.28), forest=(0.20, 0.26, 0.16),
                   rock=(0.46, 0.38, 0.40), rock2=(0.32, 0.26, 0.30), snow=(0.95, 0.85, 0.82), shallow=(0.40, 0.45, 0.55), deep=(0.10, 0.12, 0.26)),
}

# ------------------------------------------------------------------ height fields (meters, Blender Z up, +Y = forward)
def h_plains(x, y):
    coast = -1500 + 380 * fbm(0, y, 0.0009, 3, 3.1) - 0.18 * (y + 2000)
    land = sstep(coast - 120, coast + 260, x)
    hills = 38 + 42 * fbm(x, y, 0.0011, 5, 1.3) + 18 * fbm(x, y, 0.004, 3, 7.7)
    river = abs(fbm(x, y, 0.00055, 3, 11.0))
    carve = 1 - sstep(0.03, 0.085, river)
    lake = max(gauss(x, y, 700, 700, 330), gauss(x, y, -250, 1300, 260), gauss(x, y, 1200, 1600, 300))
    h = hills * (1 - max(carve, sstep(0.45, 0.75, lake))) - 9 * max(carve, sstep(0.45, 0.75, lake))
    rng_mask = gauss(x, y, 1500, 3000, 1500)
    h += 1150 * ridged(x, y, 0.00085, 6, 4.2) * rng_mask ** 1.3
    h += 260 * gauss(x, y, 700, -1850, 240) * (0.8 + 0.4 * ridged(x, y, 0.006, 3, 2.0))
    h += 300 * gauss(x, y, -1250, -250, 230) * (0.8 + 0.4 * ridged(x, y, 0.005, 3, 5.0))
    h += 120 * gauss(x, y, -600, 400, 300) * (0.7 + 0.5 * ridged(x, y, 0.006, 3, 8.0))
    sea = -22 + 10 * fbm(x, y, 0.002, 2, 9.0)
    return sea + (h - sea) * land

def h_lake(x, y):
    d = math.hypot(x / 1.25, (y - 350) / 1.0)
    rim = sstep(900, 1500, d)
    mount = 1250 * ridged(x, y, 0.0011, 6, 2.2) * rim + 260 * rim
    shore = 8 + 25 * fbm(x, y, 0.003, 3, 1.0)
    h = shore * sstep(780, 980, d) + mount - 14 * (1 - sstep(700, 900, d))
    for (cx, cy, r, a) in ((-420, -350, 70, 26), (380, 150, 55, 20), (650, -760, 35, 14), (-80, 700, 60, 18)):
        h += (a + 14) * gauss(x, y, cx, cy, r)
    return h

def h_archipelago(x, y):
    n = fbm(x, y, 0.0009, 5, 2.0) + 0.35 * fbm(x, y, 0.003, 3, 6.0)
    land = sstep(0.02, 0.16, n)
    h = -26 + 26 * land + 70 * max(0.0, n - 0.1) * land + 30 * ridged(x, y, 0.003, 3, 1.0) * land * 0.5
    far = sstep(1800, 3200, y)
    h += 900 * ridged(x, y, 0.0009, 6, 3.3) * far * gauss(x, 0, 300, 0, 2200)
    return h

def h_bay(x, y):
    left = sstep(-300, -1300, x)
    right = sstep(500, 1500, x) * sstep(-2500, 500, y)
    back = sstep(2600, 3800, y)
    h = -30 + 10 * fbm(x, y, 0.002, 2, 1.0)
    h += (left * (700 * ridged(x, y, 0.0012, 6, 1.5) + 180)) + right * (160 + 180 * fbm(x, y, 0.0015, 4, 2.0)) + back * (400 + 500 * ridged(x, y, 0.001, 5, 7.0))
    for (cx, cy, r, a) in ((-200, 1300, 160, 90), (300, 2100, 120, 70), (-500, 2500, 90, 60), (600, 1200, 70, 40)):
        h += (a + 30) * gauss(x, y, cx, cy, r) * (0.8 + 0.4 * ridged(x, y, 0.01, 2, cx))
    return h

HEIGHT = dict(plains=h_plains, lake=h_lake, archipelago=h_archipelago, bay=h_bay)

# ------------------------------------------------------------------ scene helpers
def reset():
    bpy.ops.wm.read_factory_settings(use_empty=True)

def link(ob, coll=None):
    (coll or bpy.context.scene.collection).objects.link(ob)
    return ob

def flat_material(name, rough=0.9, emission=None):
    m = bpy.data.materials.new(name)
    m.use_nodes = True
    nt = m.node_tree
    b = nt.nodes['Principled BSDF']
    ca = nt.nodes.new('ShaderNodeVertexColor'); ca.layer_name = 'Col'
    nt.links.new(ca.outputs['Color'], b.inputs['Base Color'])
    b.inputs['Roughness'].default_value = rough
    if emission:
        key = 'Emission Color' if 'Emission Color' in b.inputs else 'Emission'
        nt.links.new(ca.outputs['Color'], b.inputs[key]); b.inputs['Emission Strength'].default_value = emission
    return m

def face_colors(me, fn):
    ca = me.color_attributes.new('Col', 'BYTE_COLOR', 'CORNER')
    for p in me.polygons:
        c = srgb2lin(fn(p))
        for li in p.loop_indices:
            ca.data[li].color = (*c, 1.0)

def apply_mod(ob, mod):
    bpy.context.view_layer.objects.active = ob
    ob.select_set(True)
    bpy.ops.object.modifier_apply(modifier=mod.name)
    ob.select_set(False)

def build_terrain(P):
    S, N = P['size'], P['seg']
    hf = HEIGHT[P['terrain']]
    bm = bmesh.new()
    bmesh.ops.create_grid(bm, x_segments=N, y_segments=N, size=S)
    for v in bm.verts:
        v.co.z = hf(v.co.x, v.co.y)
    me = bpy.data.meshes.new('terrain'); bm.to_mesh(me); bm.free()
    ob = link(bpy.data.objects.new('Terrain', me))
    dec = ob.modifiers.new('LowPolyFacets', 'DECIMATE'); dec.decimate_type = 'COLLAPSE'; dec.ratio = P['decimate']; dec.use_collapse_triangulate = True
    apply_mod(ob, dec)
    me = ob.data
    for p in me.polygons:
        p.use_smooth = False
    pal = PALETTES[P['palette']]
    rng = random.Random(38)
    snow = P['snow']
    def col(p):
        c = p.center; z = c.z; slope = 1 - p.normal.z
        j = 1 + rng.uniform(-0.07, 0.07)
        if z < -0.5:
            t = sstep(-1, -16, z); return mix(pal['shallow'], pal['deep'], t)
        if z < 3.5:
            base = pal['sand']
        elif z > snow + 60 * fbm(c.x, c.y, 0.004, 2, 3.0) and slope < 0.55:
            base = pal['snow']
        elif slope > 0.42 or z > snow * 0.8:
            base = mix(pal['rock'], pal['rock2'], sstep(0.4, 0.9, slope))
        else:
            reg = 0.5 + 0.5 * fbm(c.x, c.y, 0.0016, 3, 5.0)
            base = mix(pal['grass'], pal['grass2'], sstep(0.35, 0.75, reg))
            if fbm(c.x, c.y, 0.0022, 3, 9.0) > 0.12 and slope < 0.35:
                base = mix(base, pal['forest'], 0.55)
        return tuple(min(1.0, v * j) for v in base)
    face_colors(me, col)
    me.materials.append(flat_material('TerrainFacets'))
    # tree density on points
    dens = me.attributes.new('tree_density', 'FLOAT', 'POINT')
    nrm = [0.0] * len(me.vertices)
    for p in me.polygons:
        for vi in p.vertices:
            nrm[vi] = max(nrm[vi], 1 - p.normal.z)
    for i, v in enumerate(me.vertices):
        z = v.co.z
        f = fbm(v.co.x, v.co.y, 0.0022, 3, 9.0)
        ok = (4 < z < snow * 0.75) and nrm[i] < 0.45
        dens.data[i].value = P['trees'] * (0.25 + 3.0 * max(0.0, f)) if ok else 0.0
    return ob

def tree_collection(P):
    coll = bpy.data.collections.new('TreeKit')
    pal = PALETTES[P['palette']]
    mat = flat_material('TreeFacets', 0.85)
    def piece(name, verts_faces_fn, color):
        bm = bmesh.new(); verts_faces_fn(bm)
        me = bpy.data.meshes.new(name); bm.to_mesh(me); bm.free()
        face_colors(me, lambda p: tuple(min(1, c * (1 + random.uniform(-0.08, 0.08))) for c in color))
        me.materials.append(mat)
        return me
    for k in range(3):  # pines: stacked cones + trunk, joined
        bm = bmesh.new()
        h = 14 + 4 * k
        bmesh.ops.create_cone(bm, cap_ends=True, segments=6, radius1=1.0, radius2=0.7, depth=h * 0.25, matrix=Matrix.Translation((0, 0, h * 0.12)))
        for t in range(3):
            r = (0.42 - t * 0.1) * h
            bmesh.ops.create_cone(bm, cap_ends=True, segments=7, radius1=r, radius2=0.0, depth=h * 0.45, matrix=Matrix.Translation((0, 0, h * (0.42 + t * 0.2))))
        me = bpy.data.meshes.new(f'pine{k}'); bm.to_mesh(me); bm.free()
        dark = mix(pal['forest'], (0.1, 0.2, 0.12), 0.35)
        face_colors(me, lambda p: (0.36, 0.24, 0.14) if p.center.z < h * 0.2 else tuple(min(1, c * (1 + random.uniform(-0.1, 0.1))) for c in dark))
        me.materials.append(mat)
        coll.objects.link(bpy.data.objects.new(f'pine{k}', me))
    for k in range(2):  # broadleaf: faceted icosphere crown + trunk
        bm = bmesh.new()
        bmesh.ops.create_cone(bm, cap_ends=True, segments=5, radius1=0.9, radius2=0.6, depth=6, matrix=Matrix.Translation((0, 0, 3)))
        g = bmesh.ops.create_icosphere(bm, subdivisions=1, radius=5.5 + k)
        for v in g['verts']:
            v.co = v.co * (1 + random.uniform(-0.15, 0.15)) + Vector((0, 0, 9 + k))
        me = bpy.data.meshes.new(f'broad{k}'); bm.to_mesh(me); bm.free()
        face_colors(me, lambda p: (0.36, 0.24, 0.14) if p.center.z < 5 else tuple(min(1, c * (1 + random.uniform(-0.1, 0.1))) for c in pal['forest']))
        me.materials.append(mat)
        coll.objects.link(bpy.data.objects.new(f'broad{k}', me))
    return coll

def scatter_nodes(ob, coll):
    ng = bpy.data.node_groups.new('ScatterTrees', 'GeometryNodeTree')
    ng.interface.new_socket('Geometry', in_out='INPUT', socket_type='NodeSocketGeometry')
    ng.interface.new_socket('Geometry', in_out='OUTPUT', socket_type='NodeSocketGeometry')
    n, l = ng.nodes, ng.links
    gi = n.new('NodeGroupInput'); go = n.new('NodeGroupOutput')
    dist = n.new('GeometryNodeDistributePointsOnFaces')
    na = n.new('GeometryNodeInputNamedAttribute'); na.data_type = 'FLOAT'; na.inputs['Name'].default_value = 'tree_density'
    l.new(gi.outputs[0], dist.inputs['Mesh']); l.new(na.outputs['Attribute'], dist.inputs['Density'])
    ci = n.new('GeometryNodeCollectionInfo'); ci.inputs['Collection'].default_value = coll
    ci.inputs['Separate Children'].default_value = True; ci.inputs['Reset Children'].default_value = True
    iop = n.new('GeometryNodeInstanceOnPoints'); iop.inputs['Pick Instance'].default_value = True
    l.new(dist.outputs['Points'], iop.inputs['Points']); l.new(ci.outputs[0], iop.inputs['Instance'])
    rs = n.new('FunctionNodeRandomValue'); rs.data_type = 'FLOAT'; rs.inputs[2].default_value = 0.7; rs.inputs[3].default_value = 1.35
    l.new(rs.outputs[1], iop.inputs['Scale'])
    rr = n.new('FunctionNodeRandomValue'); rr.data_type = 'FLOAT_VECTOR'; rr.inputs[0].default_value = (0, 0, 0); rr.inputs[1].default_value = (0.08, 0.08, 6.28)
    l.new(rr.outputs[0], iop.inputs['Rotation'])
    j = n.new('GeometryNodeJoinGeometry')
    l.new(gi.outputs[0], j.inputs[0]); l.new(iop.outputs[0], j.inputs[0]); l.new(j.outputs[0], go.inputs[0])
    m = ob.modifiers.new('Vegetation', 'NODES'); m.node_group = ng

def cloud(name, center, size, rng, mat):
    bm = bmesh.new()
    for i in range(rng.randint(6, 10)):
        off = Vector((rng.uniform(-1, 1) * size, rng.uniform(-0.5, 0.5) * size * 0.6, rng.uniform(0, 0.35) * size))
        g = bmesh.ops.create_icosphere(bm, subdivisions=2, radius=size * rng.uniform(0.35, 0.6))
        for v in g['verts']:
            v.co = Vector((v.co.x, v.co.y, v.co.z * 0.7)) + off
    me = bpy.data.meshes.new(name); bm.to_mesh(me); bm.free()
    ob = link(bpy.data.objects.new(name, me)); ob.location = center
    rm = ob.modifiers.new('Merge', 'REMESH'); rm.mode = 'VOXEL'; rm.voxel_size = size * 0.1
    apply_mod(ob, rm)
    dc = ob.modifiers.new('Facets', 'DECIMATE'); dc.decimate_type = 'COLLAPSE'; dc.ratio = 0.06
    apply_mod(ob, dc)
    for p in ob.data.polygons:
        p.use_smooth = False
    face_colors(ob.data, lambda p: (0.97, 0.97, 1.0) if p.normal.z > -0.2 else (0.80, 0.83, 0.90))
    ob.data.materials.append(mat)
    return ob

def world_sky(P):
    w = bpy.data.worlds.new('Sky'); bpy.context.scene.world = w; w.use_nodes = True
    nt = w.node_tree; n, l = nt.nodes, nt.links
    bg = n['Background']
    tc = n.new('ShaderNodeTexCoord')
    sep = n.new('ShaderNodeSeparateXYZ'); l.new(tc.outputs['Generated'], sep.inputs[0])
    ramp = n.new('ShaderNodeValToRGB')
    mp = n.new('ShaderNodeMapRange'); mp.inputs['From Min'].default_value = 0.0; mp.inputs['From Max'].default_value = 0.35
    l.new(sep.outputs['Z'], mp.inputs['Value']); l.new(mp.outputs[0], ramp.inputs['Fac'])
    ramp.color_ramp.elements[0].color = (*srgb2lin(P['sky']['horizon']), 1)
    ramp.color_ramp.elements[1].color = (*srgb2lin(P['sky']['zenith']), 1)
    sd = sun_dir(P)
    dot = n.new('ShaderNodeVectorMath'); dot.operation = 'DOT_PRODUCT'; dot.inputs[1].default_value = sd
    l.new(tc.outputs['Generated'], dot.inputs[0])
    pw = n.new('ShaderNodeMath'); pw.operation = 'POWER'; pw.inputs[1].default_value = 12.0; pw.use_clamp = True
    cl = n.new('ShaderNodeMath'); cl.operation = 'MAXIMUM'; cl.inputs[1].default_value = 0.0
    l.new(dot.outputs['Value'], cl.inputs[0]); l.new(cl.outputs[0], pw.inputs[0])
    add = n.new('ShaderNodeMix'); add.data_type = 'RGBA'; add.blend_type = 'ADD'
    add.inputs['B'].default_value = (*P['sky']['glow'], 1)
    l.new(pw.outputs[0], add.inputs['Factor']); l.new(ramp.outputs['Color'], add.inputs['A'])
    l.new(add.outputs['Result'], bg.inputs['Color']); bg.inputs['Strength'].default_value = 1.0
    vol = n.new('ShaderNodeVolumeScatter'); vol.inputs['Density'].default_value = P['haze']; vol.inputs['Color'].default_value = (*srgb2lin(P['haze_color']), 1)
    vol.inputs['Anisotropy'].default_value = 0.3
    l.new(vol.outputs[0], n['World Output'].inputs['Volume'])

def sun_dir(P):
    e, a = math.radians(P['sun']['elev']), math.radians(P['sun']['az'])
    return (math.cos(e) * math.cos(a), math.cos(e) * math.sin(a), math.sin(e))

def add_sun(P):
    ld = bpy.data.lights.new('Sun', 'SUN'); ld.energy = P['sun']['strength']; ld.color = P['sun']['color']; ld.angle = math.radians(1.5)
    ob = link(bpy.data.objects.new('Sun', ld))
    ob.rotation_euler = (-Vector(sun_dir(P))).to_track_quat('-Z', 'Y').to_euler()

def add_water(P):
    bm = bmesh.new(); bmesh.ops.create_grid(bm, x_segments=1, y_segments=1, size=P['size'] * 3)
    me = bpy.data.meshes.new('water'); bm.to_mesh(me); bm.free()
    ob = link(bpy.data.objects.new('Water', me))
    m = bpy.data.materials.new('Water'); m.use_nodes = True
    b = m.node_tree.nodes['Principled BSDF']
    b.inputs['Base Color'].default_value = (*srgb2lin(P['water']['color']), 1)
    b.inputs['Roughness'].default_value = P['water']['rough']; b.inputs['Alpha'].default_value = P['water']['alpha']
    if hasattr(m, 'surface_render_method'):
        m.surface_render_method = 'BLENDED'
    else:
        m.blend_method = 'BLEND'
    me.materials.append(m)

def add_ship(P, cam_pos, cam_tgt):
    path = os.path.join(HERE, 'airship.glb')
    before = set(bpy.data.objects)
    bpy.ops.import_scene.gltf(filepath=path)
    new = [o for o in bpy.data.objects if o not in before]
    root = link(bpy.data.objects.new('Airship', None))
    for o in new:
        if o.parent is None:
            o.parent = root
    bpy.context.view_layer.update()
    pts = [o.matrix_world @ Vector(c) for o in new if o.type == 'MESH' for c in o.bound_box]
    ext = max((max(p[i] for p in pts) - min(p[i] for p in pts)) for i in range(3))
    root.scale = (30.0 / ext,) * 3
    f = (Vector(cam_tgt) - Vector(cam_pos)).normalized(); r = f.cross(Vector((0, 0, 1))).normalized()
    s = P['ship']
    root.location = Vector(cam_pos) + f * s['dist'] + r * s['right'] + Vector((0, 0, s['up']))
    root.rotation_euler = (0, 0, math.radians(s['yaw']) + math.atan2(f.y, f.x))

def add_camera(P):
    (pos, tgt, fov) = P['cam']
    cd = bpy.data.cameras.new('Cam'); cd.sensor_fit = 'VERTICAL'; cd.angle = math.radians(fov); cd.clip_end = 30000; cd.clip_start = 1
    ob = link(bpy.data.objects.new('Cam', cd)); ob.location = pos
    ob.rotation_euler = (Vector(tgt) - Vector(pos)).to_track_quat('-Z', 'Y').to_euler()
    bpy.context.scene.camera = ob
    return pos, tgt

def render_settings():
    sc = bpy.context.scene
    for eng in ('BLENDER_EEVEE_NEXT', 'BLENDER_EEVEE'):
        try:
            sc.render.engine = eng; break
        except TypeError:
            pass
    sc.render.resolution_x, sc.render.resolution_y, sc.render.resolution_percentage = 1672, 941, 100
    ee = sc.eevee
    for k, v in (('taa_render_samples', 48), ('use_raytracing', True), ('volumetric_end', 14000.0), ('volumetric_tile_size', '8'),
                 ('use_shadows', True), ('shadow_ray_count', 2), ('use_gtao', True), ('gtao_distance', 30.0)):
        try:
            setattr(ee, k, v)
        except Exception:
            pass
    sc.view_settings.view_transform = 'Standard'; sc.view_settings.look = 'None'
    sc.render.image_settings.file_format = 'PNG'

def build(ref):
    P = PRESETS[ref]
    reset()
    render_settings()
    world_sky(P)
    add_sun(P)
    terr = build_terrain(P)
    scatter_nodes(terr, tree_collection(P))
    add_water(P)
    rng = random.Random(int(ref))
    cmat = flat_material('CloudFacets', 0.95, emission=0.25)
    (pos, tgt, fov) = P['cam']
    f = (Vector(tgt) - Vector(pos)).normalized()
    for i in range(P['clouds']):
        d = rng.uniform(1500, 5000)
        side = rng.uniform(-1.0, 1.0) * d * 0.8
        c = Vector(pos) + Vector((f.x, f.y, 0)).normalized() * d + Vector((-f.y, f.x, 0)).normalized() * side
        c.z = rng.uniform(550, 1300) if ref != '1128' else rng.uniform(900, 1600)
        cloud(f'cloud{i}', c, rng.uniform(120, 260), rng, cmat)
    pos, tgt = add_camera(P)
    add_ship(P, pos, tgt)
    bpy.context.scene.render.filepath = os.path.join(OUT, ref + '.png')
    bpy.ops.render.render(write_still=True)
    bpy.ops.wm.save_as_mainfile(filepath=os.path.join(OUT, ref + '.blend'))
    tris = sum(len(p.vertices) - 2 for p in terr.data.polygons)
    return dict(terrain_triangles=tris, preset=P['terrain'])

args = sys.argv[sys.argv.index('--') + 1:] if '--' in sys.argv else []
refs = args or list(PRESETS)
report = {'blender': bpy.app.version_string, 'results': {}}
for ref in refs:
    try:
        report['results'][ref] = build(ref)
        print('[ok]', ref, report['results'][ref], flush=True)
    except Exception:
        report['results'][ref] = {'error': traceback.format_exc()}
        print('[fail]', ref, traceback.format_exc(), flush=True)
    with open(os.path.join(OUT, 'report.json'), 'w') as fh:
        json.dump(report, fh, indent=1)
print('[done]', flush=True)
